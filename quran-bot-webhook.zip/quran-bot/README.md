# Quran Bot (aiogram v3) — Webhook Ready

## Quick Start (Render)
1) Add environment variables:
```
BOT_TOKEN=...       # from @BotFather
WEBHOOK_URL=https://your-service.onrender.com/telegram/webhook
WEBAPP_HOST=0.0.0.0
WEBAPP_PORT=8080
QURAN_MAX_PAGES=604
QURAN_IMG_DIR=assets/quran
```
2) Ensure at least one sample image exists: `assets/quran/0001.jpg`.
3) Start command: `python bot.py`.

Use /start to open the main menu → Quran → page navigation (next/prev).
