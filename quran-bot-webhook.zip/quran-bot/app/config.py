from dataclasses import dataclass
import os
from dotenv import load_dotenv

load_dotenv()

@dataclass
class Settings:
    BOT_TOKEN: str = os.getenv("BOT_TOKEN", "")
    ADMINS: list[int] = None
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./bot.db")
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")

    # Webhook
    WEBHOOK_URL: str = os.getenv("WEBHOOK_URL", "")
    WEBAPP_HOST: str = os.getenv("WEBAPP_HOST", "0.0.0.0")
    WEBAPP_PORT: int = int(os.getenv("WEBAPP_PORT", 8080))

    def __post_init__(self):
        admins_raw = os.getenv("ADMINS", "").strip()
        self.ADMINS = [int(x) for x in admins_raw.split(',') if x.strip().isdigit()] if admins_raw else []

settings = Settings()

if not settings.BOT_TOKEN:
    raise RuntimeError("Please set BOT_TOKEN in the environment (.env)")
