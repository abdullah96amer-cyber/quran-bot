from aiogram import Router
from aiogram.types import Message
from aiogram.filters import Command
from app.config import settings
from app.db import SessionLocal

router = Router()

@router.message(Command("broadcast"))
async def broadcast(msg: Message):
    """بث رسائل نصية إلى جميع المستخدمين المسجلين."""
    if msg.from_user.id not in settings.ADMINS:
        return await msg.answer("هذا الأمر للإدارة فقط.")

    text = msg.text.partition(' ')[2].strip()
    if not text:
        return await msg.answer("استخدم: /broadcast <النص>")

    async with SessionLocal() as session:
        rows = (await session.execute("SELECT id FROM users")).all()

    from aiogram import Bot
    bot = Bot(settings.BOT_TOKEN, parse_mode=None)

    sent = 0
    failed = 0
    for (uid,) in rows:
        try:
            await bot.send_message(uid, text)
            sent += 1
        except Exception:
            failed += 1
            continue

    await msg.answer(f"تم الإرسال إلى {sent} مستخدم، فشل إلى {failed}.")
