from aiogram import Router
from aiogram.types import Message
from aiogram.filters import Command

router = Router()

@router.message(Command("help"))
async def cmd_help(msg: Message):
    await msg.answer(
        "🆘 **مساعدة**\n\nالأوامر المتاحة:\n- /start\n- /help\n- /menu\n- /profile\n\nللإدارة: /broadcast <نص>",
        parse_mode="Markdown"
    )
