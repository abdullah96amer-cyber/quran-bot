from aiogram import Router, F
from aiogram.types import Message
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from app.states.profile import ProfileStates
from app.db import SessionLocal, User

router = Router()

@router.message(Command("profile"))
async def profile_entry(msg: Message, state: FSMContext):
    await state.set_state(ProfileStates.waiting_for_name)
    await msg.answer("أرسل لي اسمك الجديد كما تريد ظهوره في ملفك.")

@router.message(ProfileStates.waiting_for_name, F.text.len() >= 2)
async def set_name(msg: Message, state: FSMContext):
    new_name = msg.text.strip()[:128]
    async with SessionLocal() as session:
        user = await session.get(User, msg.from_user.id)
        if user:
            user.first_name = new_name
            await session.commit()
    await state.clear()
    await msg.answer(f"تم تحديث اسمك إلى: {new_name}")

@router.message(ProfileStates.waiting_for_name)
async def bad_name(msg: Message):
    await msg.answer("الاسم قصير جدًا. أعد المحاولة (2 أحرف على الأقل).")
