from aiogram import Router, F
from aiogram.types import CallbackQuery, InputMediaPhoto
from app.config import settings
from app.keyboards.common import quran_nav_kb, main_menu_kb
import os

router = Router()

MAX_PAGES = int(os.getenv("QURAN_MAX_PAGES", "604"))
IMG_BASE = os.getenv("QURAN_IMG_BASE", "").rstrip("/")
IMG_DIR = os.getenv("QURAN_IMG_DIR", "assets/quran")

def page_to_path(page: int):
    filename = f"{page:04d}.jpg"
    if IMG_BASE:
        return f"{IMG_BASE}/{filename}", True
    return os.path.join(IMG_DIR, filename), False

@router.callback_query(F.data == "menu:quran")
async def open_quran(cq: CallbackQuery):
    page = 1
    src, remote = page_to_path(page)
    caption = f"الصفحة {page} / {MAX_PAGES}"
    try:
        await cq.message.edit_text("جارٍ عرض الصفحة…")
        media = InputMediaPhoto(media=src if remote else open(src, "rb"), caption=caption)
        await cq.message.edit_media(media=media, reply_markup=quran_nav_kb(page, MAX_PAGES))
    except Exception:
        await cq.message.edit_text("تعذّر تحميل الصورة. تأكد من المسار/الرابط ثم أعد المحاولة.")
        await cq.message.edit_reply_markup(reply_markup=main_menu_kb())
    await cq.answer()

@router.callback_query(F.data.startswith("quran:page:"))
async def quran_page(cq: CallbackQuery):
    try:
        page = int(cq.data.split(":")[-1])
    except ValueError:
        page = 1
    page = max(1, min(MAX_PAGES, page))

    src, remote = page_to_path(page)
    caption = f"الصفحة {page} / {MAX_PAGES}"

    try:
        media = InputMediaPhoto(media=src if remote else open(src, "rb"), caption=caption)
        await cq.message.edit_media(media=media, reply_markup=quran_nav_kb(page, MAX_PAGES))
    except Exception:
        await cq.message.edit_text("تعذّر تحميل الصورة. تأكد من المسار/الرابط.")
        await cq.message.edit_reply_markup(reply_markup=main_menu_kb())
    await cq.answer()

@router.callback_query(F.data == "menu:adhkar")
async def open_adhkar(cq: CallbackQuery):
    await cq.message.edit_text("قريبًا: الأذكار اليومية. 🌙", reply_markup=main_menu_kb())
    await cq.answer()

@router.callback_query(F.data == "menu:dua")
async def open_dua(cq: CallbackQuery):
    await cq.message.edit_text("قريبًا: مجموعة مختارة من الأدعية. 🤲", reply_markup=main_menu_kb())
    await cq.answer()
