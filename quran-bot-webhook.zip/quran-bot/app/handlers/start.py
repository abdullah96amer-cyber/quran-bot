from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart, Command
from app.db import SessionLocal, User
from app.keyboards.common import main_menu_kb

router = Router()

@router.message(CommandStart())
async def cmd_start(msg: Message):
    async with SessionLocal() as session:
        user = await session.get(User, msg.from_user.id)
        if not user:
            user = User(id=msg.from_user.id,
                        first_name=msg.from_user.first_name,
                        username=msg.from_user.username)
            session.add(user)
            await session.commit()
    await msg.answer(
        "مرحبًا بك! 👋\nاختر من القائمة أدناه: ختم القرآن الكريم، الأذكار، الأدعية.",
        reply_markup=main_menu_kb()
    )

@router.message(Command("menu"))
async def cmd_menu(msg: Message):
    await msg.answer("القائمة الرئيسية:", reply_markup=main_menu_kb())

@router.callback_query(F.data == "menu:home")
async def cb_home(cq: CallbackQuery):
    await cq.message.edit_text("القائمة الرئيسية:")
    await cq.message.edit_reply_markup(reply_markup=main_menu_kb())
    await cq.answer()
