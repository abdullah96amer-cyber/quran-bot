from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def main_menu_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📖 ختم القرآن الكريم", callback_data="menu:quran")],
        [InlineKeyboardButton(text="🕋 الأذكار", callback_data="menu:adhkar")],
        [InlineKeyboardButton(text="🤲 الأدعية", callback_data="menu:dua")],
    ])

def quran_nav_kb(page: int, max_pages: int) -> InlineKeyboardMarkup:
    buttons = []
    if page > 1:
        buttons.append(InlineKeyboardButton(text="⬅️ السابق", callback_data=f"quran:page:{page-1}"))
    if page < max_pages:
        buttons.append(InlineKeyboardButton(text="التالي ➡️", callback_data=f"quran:page:{page+1}"))
    rows = [buttons] if buttons else [[]]
    rows.append([InlineKeyboardButton(text="🏠 القائمة", callback_data="menu:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)
