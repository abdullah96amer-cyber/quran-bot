import time
from aiogram import BaseMiddleware
from aiogram.types import TelegramObject
from typing import Callable, Dict, Any

class RateLimitMiddleware(BaseMiddleware):
    def __init__(self, calls: int = 3, per_seconds: float = 2.0):
        super().__init__()
        self.calls = calls
        self.per_seconds = per_seconds
        self.buckets: Dict[int, list[float]] = {}

    async def __call__(self, handler: Callable[[TelegramObject, Dict[str, Any]], Any], event: TelegramObject, data: Dict[str, Any]):
        user_id = getattr(getattr(event, 'from_user', None), 'id', None)
        if user_id:
            now = time.monotonic()
            q = self.buckets.setdefault(user_id, [])
            q[:] = [t for t in q if now - t < self.per_seconds]
            if len(q) >= self.calls:
                return
            q.append(now)
        return await handler(event, data)
