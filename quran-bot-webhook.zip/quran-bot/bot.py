import asyncio
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from app.config import settings
from app.logger import logger
from app.db import init_db
from app.middlewares.rate_limit import RateLimitMiddleware
from app.handlers import start as start_h
from app.handlers import help as help_h
from app.handlers import profile as profile_h
from app.handlers import admin as admin_h
from app.handlers import quran as quran_h

async def on_startup(dp: Dispatcher):
    logger.info("Initializing DB...")
    await init_db()
    logger.info("Ready ✅")

async def main():
    bot = Bot(settings.BOT_TOKEN)
    dp = Dispatcher(storage=MemoryStorage())

    dp.message.middleware(RateLimitMiddleware(calls=3, per_seconds=2))

    dp.include_router(start_h.router)
    dp.include_router(help_h.router)
    dp.include_router(profile_h.router)
    dp.include_router(quran_h.router)
    dp.include_router(admin_h.router)

    await on_startup(dp)

    if settings.WEBHOOK_URL:
        from fastapi import FastAPI, Request
        from aiogram.types import Update
        import uvicorn

        app = FastAPI()

        @app.on_event("startup")
        async def _set_webhook():
            await bot.set_webhook(settings.WEBHOOK_URL)
            logger.info("Webhook set: %s", settings.WEBHOOK_URL)

        @app.post("/telegram/webhook")
        async def telegram_webhook(request: Request):
            payload = await request.json()
            update = Update.model_validate(payload)
            await dp.feed_update(bot, update)
            return {"ok": True}

        uvicorn.run(app, host=settings.WEBAPP_HOST, port=settings.WEBAPP_PORT)
    else:
        await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
